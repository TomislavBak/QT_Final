#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QPushButton>
#include<QLineEdit>
#include<QFile>
#include<QDebug>
#include<QStandardItemModel>
#include<Qt>
#include<QBitmap>
#include"country.h"

QVector<Country>countries;


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);


    QStandardItemModel *row_model = new QStandardItemModel(this);



    //File read
    QFile file(":/countries/countries/countries.txt");
    if(!file.open(QIODevice::ReadOnly)) {
        qDebug()<<file.errorString();
    }
    else{
        qDebug()<<"Success";
    }
    QTextStream in(&file);

    //Setting data
    while(!in.atEnd()) {


        QString line = in.readLine();
        QStringList fields = line.split(",");


        fields[1].remove(0,1);

        row_model->appendRow(new QStandardItem(QIcon(":/flags/flags/"+fields[0]+".jpg"), fields[2]+"+"+ fields[1].simplified().remove(" ")));

        QString flags_no_space = fields[0].simplified().remove(" ");
        QString prefix_no_space = fields[1].simplified().remove(" ");

        Country country(fields[2],flags_no_space,fields[1].simplified().remove(" "));
        countries.push_back(country);

    }
    // end settin data


    file.close();

    // end file read

    ui->listView->setModel(row_model); // setting model






    //Background
   ui->centralwidget->setStyleSheet("background-image:url(:/resources/resources/bgd_bubbles.png);"
                                    );
    //end Background

   //Send Button
   ui->pushButton_send->setStyleSheet(" background-image:url(:/resources/resources/btn_white_normal.png); "
                                 "background-repeat: no-repeat;"
                                 "height: 28px ; width: 41px;"
                                 "background-position: center;"
                                 "background-color:transparent");
   ui->pushButton_send->setText("Send");
   //end Send Button



    //LineEdit
   QBitmap map(":/resources/resources/field_normal.png");
   ui->lineEdit->setMask(map.mask());
   //ui->lineEdit->setStyleSheet("background-color:white");
  // ui->lineEdit->setStyleSheet(" background-image:url(:/resources/resources/field_normal.png);"
                               //"background-repeat: no-repeat;"
                              // "height: 22px;"
                              // "background-position: center;"
                              // "background-color:transparent;"
                              // "background-color:transparent;"
                              // "width:100vw; height:100hw"
                              // );
   ui->lineEdit->setPlaceholderText("enter phone number");
    //end LineEdit

    //Text Edit
   ui->textEdit->setStyleSheet("background-color:white");
   ui->textEdit->setPlaceholderText("Type message");
   //end Text Edit

    // word count
    ui->label_numberCount->setStyleSheet("background-color:transparent");
    ui->label_numberCount->setText("0");
    // word count

    // listView
    ui->listView->hide();
    ui->listView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->listView->setStyleSheet("background-color:white");
    // end list view

    // combo arrow push btn
    ui->pushButton_arrow->setStyleSheet("background-image : url(:/resources/resources/combo_arrow.png);"
                                    "background-repeat: no-repeat;"
                                    "background-position: center;"
                                    "background-color:transparent");
    ui->pushButton_arrow->setText("");
    // end combo arrow push btn

    // call button
    ui->pushButton_call->setStyleSheet("background-image : url(:/resources/resources/icons8-phone-24.png);"
                                    "background-repeat: no-repeat;"
                                    "background-position: center");
    ui->pushButton_call->setText("");
    // call button end

    // see rates label
    ui->label_seeRates->setStyleSheet("background-color:transparent");
    ui->label_seeRates->setText("See rates");
    // end see rates label

    // call label
    ui->label_Call->setStyleSheet("background-color:transparent");
    ui->label_Call->setText("Call");
    // call label end

    // credit label
    ui->label_Credit->setStyleSheet("background-color:transparent");
    ui->label_Credit->setText("Credit");
    // credit label end

    // credit num label
    ui->label_textNumber->setStyleSheet("background-color:transparent");
    ui->label_textNumber->setNum(0.00);
    // credit label num end

    // buy credit label
    ui->label_buyCredit->setStyleSheet("background-color:transparent");
    ui->label_buyCredit->setText("Buy credit");
    // buy credit label end

    ui->label_numberOf->setText("/0");
    ui->label_numberOf->setStyleSheet("background-color:transparent");

    ui->label_numberCount->setNum(160);










}

MainWindow::~MainWindow()
{
    delete ui;
}

//Text number
void MainWindow::on_textEdit_textChanged()
{
    static int max_len = 160;
    static int number_of=0;
    int len = ui->textEdit->toPlainText().length();
    len = max_len-len;
    ui->label_numberCount->setNum(len);
    if(len==0){
        number_of++;
        max_len=(number_of+1)*160;
    }

    ui->label_numberOf->setText("/"+QString::number(number_of));

}
//end Text number

//show list
void MainWindow::on_pushButton_2_clicked()
{
  ui->listView->show();
}
// end show list

// on item selected from listview
void MainWindow::on_listView_clicked(const QModelIndex &index)
{
    qDebug()<<12;
    QString itemText = index.data(Qt::DisplayRole).toString();
    QStringList prefix = itemText.split("+");
    QString p = prefix[1];
    QString z;
    QString z1;



    for(int i = 0;i<countries.size();i++){
        if(countries[i].get_prefix_number()==p){
            z1 = countries[i].get_flag_number();
            ui->lineEdit->setText(p);
            ui->pushButton_arrow->setStyleSheet(" background-image:url(:/flags/flags/"+z1+".jpg);"
                                            "background-repeat: no-repeat;"
                                            "background-position: center"
                                            );
        }
    }



    //ui->lineEdit->setText(p);
    //ui->pushButton_arrow->setStyleSheet(" background-image:url(:/flags/flags/"+z1+".jpg);"
                                   // "background-repeat: no-repeat;"
                                   // "background-position: center"
                                    //);
     ui->listView->hide();

}
// on item selected from listview


// hide list
void MainWindow::on_lineEdit_selectionChanged()
{
    ui->listView->hide();
}
//end hide list




void MainWindow::on_lineEdit_textEdited(const QString &arg1)
{
    ui->listView->hide();


    for(int i = 0;i<countries.size();i++){
        if(countries[i].get_prefix_number()==arg1)
            ui->pushButton_arrow->setStyleSheet(" background-image:url(:/flags/flags/"+countries[i].get_flag_number()+".jpg);"
                                            "background-repeat: no-repeat;"
                                            "background-position: center");
    }


}

void MainWindow::on_lineEdit_textChanged(const QString &arg1)
{

    for(int i = 0;i<countries.size();i++){
        if(countries[i].get_prefix_number()==arg1)
            ui->pushButton_arrow->setStyleSheet(" background-image:url(:/flags/flags/"+countries[i].get_flag_number()+".jpg);"
                                            "background-repeat: no-repeat;"
                                            "background-position: center");
    }

}

void MainWindow::on_lineEdit_editingFinished()
{
    for(int i = 0;i<countries.size();i++){
        if(countries[i].get_prefix_number()==ui->lineEdit->text())
            ui->pushButton_arrow->setStyleSheet(" background-image:url(:/flags/flags/"+countries[i].get_flag_number()+".jpg);"
                                            "background-repeat: no-repeat;"
                                            "background-position: center");
    }
}

void MainWindow::on_pushButton_arrow_clicked()
{
   ui->listView->show();
}

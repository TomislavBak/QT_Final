#ifndef COUNTRY_H
#define COUNTRY_H
#include<QString>

class Country
{
public:
    Country(QString="",QString="",QString="");
    QString get_name();
    QString get_flag_number();
    QString get_prefix_number();


private:
    QString country_name;
    QString flag_number;
    QString prefix_number;

};

#endif // COUNTRY_H
